# 🎯 PySpark Interview Q&A — Banking / Fraud EDA Project

> Prepared for: Data Engineering, Data Science, and Big Data roles  
> Focus areas: PySpark internals, performance, EDA, banking domain

---

## 🔵 Core PySpark Concepts

**Q1. What is the difference between `repartition()` and `coalesce()`?**  
**A:** `repartition(n)` performs a **full shuffle** across the network to create exactly `n` partitions — useful when increasing partitions or balancing skewed data. `coalesce(n)` reduces partitions with a **minimal shuffle** by combining existing ones — preferred when reducing partition count after filtering. In this project, we use `repartition` when splitting by `IsNight` for parallel processing and `coalesce` after filtering fraud-only rows.

---

**Q2. What is lazy evaluation in PySpark and why is it important?**  
**A:** PySpark operations are **lazily evaluated** — transformations like `filter()`, `withColumn()`, `groupBy()` build a DAG (Directed Acyclic Graph) but execute nothing immediately. Only **actions** (`.count()`, `.show()`, `.collect()`, `.write`) trigger execution. This allows Spark's Catalyst optimizer to reorder, combine, and optimize operations before running. Benefit: Spark can push filters down to the data source (predicate pushdown) and avoid unnecessary scans.

---

**Q3. How is PySpark different from Pandas?**  

| Feature | Pandas | PySpark |
|---|---|---|
| Execution | Single machine | Distributed cluster |
| Data size | Up to RAM | Petabyte scale |
| Evaluation | Eager | Lazy |
| Mutability | Mutable | Immutable DataFrames |
| API | Rich, flexible | SQL-like, functional |
| Speed (large data) | Slow | Fast (parallelism) |

---

**Q4. Explain the Catalyst optimizer.**  
**A:** Catalyst is Spark SQL's query optimization engine. It transforms a query through 4 phases:
1. **Parsing** → unresolved logical plan
2. **Analysis** → resolved logical plan (schema/type checks)
3. **Logical Optimization** → constant folding, predicate pushdown, projection pruning
4. **Physical Planning** → chooses join strategies (broadcast vs sort-merge), generates code  
In this project, Catalyst automatically pushes `.filter(Class==1)` before joins and prunes unused V-columns from scans.

---

**Q5. What is the difference between `cache()` and `persist()`?**  
**A:** `cache()` is shorthand for `persist(StorageLevel.MEMORY_AND_DISK)`. `persist()` allows you to specify the storage level:
- `MEMORY_ONLY` — fastest, fails if not enough RAM
- `MEMORY_AND_DISK` — spills to disk if needed (default via `cache()`)
- `DISK_ONLY` — slowest, no RAM use  
In this project, we cache `df_features` before the multi-pass EDA to avoid re-reading and re-transforming the dataset on every action.

---

## 🟡 SQL & DataFrame API

**Q6. When would you use Spark SQL over the DataFrame API?**  
**A:** Spark SQL is preferable when:
- Analysts (non-Pythonists) need to contribute queries
- Queries are complex with multiple subqueries or CTEs
- Readability matters more than API flexibility  
The DataFrame API is preferable for:
- Programmatic query building
- Reusable, parameterized functions
- IDE autocomplete and type checking  
Both compile to the same physical plan via Catalyst, so performance is identical.

---

**Q7. What does `createOrReplaceTempView` do?**  
**A:** Registers a DataFrame as a temporary SQL table accessible only within the current SparkSession. It's stored in the session catalog, not persisted to disk. When the session ends, the view is automatically dropped. We use this to run all 6 SQL queries in `spark_sql_queries.py` against the feature-engineered DataFrame.

---

**Q8. How does `approxQuantile()` differ from an exact quantile computation?**  
**A:** `approxQuantile(col, [0.25, 0.75], 0.01)` uses the **Greenwald-Khanna algorithm** to approximate percentiles within `relativeError=0.01` (1% tolerance). Exact quantiles require a full sort — `O(n log n)` — which is expensive in distributed systems. For IQR-based outlier detection, 1% tolerance is acceptable and runs 5-10× faster.

---

## 🟠 Performance & Architecture

**Q9. Explain the concept of a Shuffle in Spark.**  
**A:** A shuffle occurs when data must be redistributed across partitions — typically from `groupBy`, `join`, `distinct`, `repartition`, `orderBy`. It involves:
1. **Map phase**: Each executor writes shuffle data to local disk
2. **Network transfer**: Data moves across nodes
3. **Reduce phase**: Executors read their assigned partitions  
Shuffles are the most expensive Spark operations. We minimise them by:
- Using broadcast joins for small DataFrames
- Setting `spark.sql.shuffle.partitions=200` appropriately
- Enabling AQE (Adaptive Query Execution) to dynamically coalesce small partitions

---

**Q10. What is Adaptive Query Execution (AQE)?**  
**A:** AQE (introduced in Spark 3.0) reoptimizes query plans **at runtime** using actual statistics from completed shuffle stages. Key features:
- **Dynamically coalesces shuffle partitions** (avoids many tiny partitions)
- **Converts sort-merge joins to broadcast joins** when one table is small
- **Handles data skew** by splitting large partitions  
We enable it in `spark_config.yaml` via `spark.sql.adaptive.enabled=true`.

---

**Q11. What is predicate pushdown and how does it help?**  
**A:** Predicate pushdown moves filter conditions as close to the data source as possible — into the file scan itself rather than after reading. For Parquet files, Spark uses Parquet's built-in min/max statistics to skip entire row groups that can't satisfy the filter. Example: `df.filter(col("Class") == 1)` on a Parquet file will skip row groups where max(Class) == 0, reading only relevant data. This can reduce I/O by 50-95% on selective queries.

---

## 🔴 Banking / Domain Questions

**Q12. What is class imbalance and how do you handle it?**  
**A:** Class imbalance means one class has far more samples than another. In this dataset: 99.83% legitimate vs 0.17% fraud. Without handling:
- Models learn to predict "always legitimate" and get 99.83% accuracy but 0% fraud detection
- Precision/Recall on the minority class collapses  
Solutions:
1. **SMOTE** (Synthetic Minority Oversampling)
2. **Class weights** in the loss function (`weightCol` in Spark MLlib)
3. **Undersampling** the majority class
4. **Threshold tuning** — lower decision threshold for fraud
5. **Evaluation metrics**: Use F1-score, PR-AUC instead of accuracy

---

**Q13. Why do we use PCA-transformed features (V1–V28)?**  
**A:** The dataset provider (ULB Machine Learning Group) applied PCA to protect cardholder privacy — the original features (merchant, card number, location) are confidential. PCA also:
- Removes multicollinearity between raw features
- Reduces dimensionality (original had 28+ raw features)
- Each Vn component is orthogonal (no linear correlation)  
This is common in real banking datasets shared publicly.

---

**Q14. Why is `LogAmount` better than raw `Amount` as a feature?**  
**A:** The `Amount` column is right-skewed — most transactions are small ($0–$100) but a few exceed $25,000. Log transformation (`log1p`) compresses the right tail, making the distribution more normal. This benefits:
- Distance-based algorithms (KNN, SVM) that are sensitive to scale
- Linear models that assume normally distributed inputs
- Gradient-based optimization (faster convergence)  
We use `log1p` (log(1+x)) instead of `log` to handle zero-amount transactions gracefully.

---

**Q15. A senior engineer says your Spark job is slow. How do you debug it?**  
**A:** Step-by-step approach:
1. **Check Spark UI** (localhost:4040) — look for stages with high shuffle write/read
2. **Identify skewed partitions** — one stage with 1 task taking 10× longer than others
3. **Check for too many/few partitions** — `df.rdd.getNumPartitions()`
4. **Review execution plan** — `df.explain()` — look for Broadcast vs SortMerge joins
5. **Eliminate wide transformations** where possible
6. **Cache DataFrames** used multiple times (`df.cache()`)
7. **Use Parquet instead of CSV** for all intermediate writes
8. **Tune shuffle partitions** — default 200 may be too high for small data

---

## 🟣 Code / Debugging

**Q16. What does `F.col("Amount")` do vs just `"Amount"` in PySpark?**  
**A:** `F.col("Amount")` creates a **Column object** — a typed reference to a column that supports operators, functions, and chaining. Plain string `"Amount"` works in some contexts (like `select`, `orderBy`) but not in expressions like `.when()`, `.cast()`, or arithmetic. Best practice: always use `F.col()` in transformations to avoid ambiguity, especially in complex expressions like `F.when(F.col("Amount") > 100, "High").otherwise("Low")`.

---

**Q17. Explain the Window function used in rolling aggregations.**  
**A:** A Window in PySpark defines a group of rows relative to the current row for running aggregate calculations. In `add_rolling_features()`:
```python
w = Window.orderBy("Time").rowsBetween(-10, -1)
F.avg("Amount").over(w)
```
- `orderBy("Time")` sorts rows chronologically
- `rowsBetween(-10, -1)` looks at the 10 rows BEFORE the current row (not including it)
- `F.avg("Amount").over(w)` computes average amount over that window  
This simulates a "trailing average" — what would a fraud model have seen in the last 10 transactions before this one?

---

*End of Interview Q&A*
