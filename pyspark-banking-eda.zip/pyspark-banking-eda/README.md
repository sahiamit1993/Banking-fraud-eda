# 🏦 PySpark Banking Fraud EDA

> End-to-end PySpark data engineering & EDA project on real-world credit card fraud data.  
> Built for GitHub portfolio showcase.

[![Python](https://img.shields.io/badge/Python-3.11-blue?logo=python)](https://python.org)
[![PySpark](https://img.shields.io/badge/PySpark-3.5.1-orange?logo=apache-spark)](https://spark.apache.org)
[![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-orange?logo=jupyter)](https://jupyter.org)

---

## 📋 Table of Contents

1. [Project Overview](#project-overview)
2. [Dataset](#dataset)
3. [Tech Stack](#tech-stack)
4. [Project Architecture](#project-architecture)
5. [Folder Structure](#folder-structure)
6. [Setup Instructions](#setup-instructions)
7. [How to Run](#how-to-run)
8. [EDA Highlights](#eda-highlights)
9. [Business Insights](#business-insights)
10. [Performance Optimization](#performance-optimization)
11. [Interview Q&A](#interview-qa)

---

## 📌 Project Overview

This project performs a complete **PySpark EDA pipeline** on the Credit Card Fraud Detection dataset. It covers:

- ✅ Data ingestion (CSV → Parquet)
- ✅ Schema enforcement & type casting
- ✅ Data cleaning (nulls, duplicates, outlier capping)
- ✅ Full EDA with 6 visualizations
- ✅ Feature engineering (time, amount, rolling window)
- ✅ 6 Spark SQL business queries
- ✅ Performance optimization (caching, partitioning, AQE)
- ✅ Business insights with actionable recommendations
- ✅ Interview Q&A (17 questions with detailed answers)

---

## 📦 Dataset

| Property | Value |
|---|---|
| **Name** | Credit Card Fraud Detection |
| **Source** | Kaggle (ULB Machine Learning Group) |
| **Download** | https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud |
| **File** | `creditcard.csv` (~143 MB) |
| **Rows** | 284,807 transactions |
| **Columns** | 31 (Time, V1–V28, Amount, Class) |
| **Period** | September 2013, European cardholders |
| **Fraud rate** | 0.172% (492 fraudulent transactions) |

### Column Description

| Column | Description |
|---|---|
| `Time` | Seconds elapsed since first transaction |
| `V1–V28` | PCA-anonymised features (original features are confidential) |
| `Amount` | Transaction amount in USD |
| `Class` | **Target** — 0 = Legitimate, 1 = Fraud |

---

## 🛠️ Tech Stack

| Tool | Version | Purpose |
|---|---|---|
| Python | 3.11 | Core language |
| PySpark | 3.5.1 | Distributed data processing |
| Pandas | 2.2.2 | Pandas interop & plotting prep |
| Matplotlib | 3.8.4 | Static visualizations |
| Seaborn | 0.13.2 | Statistical plots |
| Plotly | 5.22.0 | Interactive charts |
| JupyterLab | 4.2.1 | Notebook environment |
| PyYAML | 6.0.1 | Config management |
| Loguru | 0.7.2 | Structured logging |

---

## 🏗️ Project Architecture

```
Raw CSV (143 MB)
      │
      ▼
┌─────────────────────┐
│   Data Ingestion    │  Explicit schema, CSV → Parquet
│  (data_loader.py)   │  3-10x faster subsequent reads
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│   Data Cleaning     │  Nulls, duplicates, IQR outlier cap
│  (data_cleaner.py)  │  Winsorization preserves fraud rows
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│   EDA               │  Class dist, amounts, time patterns,
│  (exploratory_      │  correlations, box plots, heatmap
│   analysis.py)      │
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│ Feature Engineering │  Time bins, log-amount, rolling avg
│  (feature_builder)  │  PySpark ML VectorAssembler + Scaler
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│   Spark SQL         │  6 business queries on temp view
│  (spark_sql_        │  Fraud by hour, amount, financial impact
│   queries.py)       │
└────────┬────────────┘
         │
         ▼
┌─────────────────────┐
│ Business Insights   │  Actionable recommendations
│ + Optimizations     │  Cache, AQE, partitioning, explain()
└─────────────────────┘
```

---

## 📁 Folder Structure

```
pyspark-banking-eda/
│
├── config/
│   └── spark_config.yaml       # SparkSession config (memory, AQE, paths)
│
├── data/
│   ├── raw/                    # Place creditcard.csv here
│   ├── processed/              # Cleaned Parquet files (auto-generated)
│   └── sample/                 # 10% stratified sample (auto-generated)
│
├── notebooks/
│   └── banking_fraud_eda.ipynb # Main Jupyter notebook (all 8 sections)
│
├── src/
│   ├── utils/
│   │   ├── spark_session.py    # SparkSession factory
│   │   └── helpers.py          # Profiling, null checks, timer decorator
│   │
│   ├── ingestion/
│   │   └── data_loader.py      # CSV/Parquet load/save, sample creator
│   │
│   ├── cleaning/
│   │   └── data_cleaner.py     # Nulls, duplicates, IQR outlier capping
│   │
│   ├── eda/
│   │   └── exploratory_        # 6 EDA functions + visualizations
│   │       analysis.py
│   │
│   ├── feature_engineering/
│   │   └── feature_builder.py  # Time, amount, rolling features + ML pipeline
│   │
│   └── sql_analysis/
│       └── spark_sql_queries.py # 6 Spark SQL business queries
│
├── outputs/
│   ├── plots/                  # Auto-saved PNG visualizations
│   └── reports/                # Summary reports
│
├── docs/
│   └── INTERVIEW_QA.md         # 17 PySpark interview Q&A
│
├── .gitignore
├── requirements.txt
└── README.md
```

---

## ⚙️ Setup Instructions

### Prerequisites

- Java 8 or 11 (required by Spark)
- Python 3.9+
- pip

### Step 1: Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/pyspark-banking-eda.git
cd pyspark-banking-eda
```

### Step 2: Create virtual environment

```bash
python -m venv venv

# Activate
source venv/bin/activate        # macOS / Linux
venv\Scripts\activate           # Windows
```

### Step 3: Install dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Install Java (if not installed)

```bash
# macOS (Homebrew)
brew install openjdk@11

# Ubuntu / Debian
sudo apt-get install openjdk-11-jdk

# Verify
java -version
```

### Step 5: Download the dataset

1. Go to: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
2. Click **Download**
3. Extract and place `creditcard.csv` into `data/raw/`

```
data/
└── raw/
    └── creditcard.csv   ✅
```

---

## ▶️ How to Run

### Option A: Jupyter Notebook (Recommended)

```bash
jupyter lab
# Open: notebooks/banking_fraud_eda.ipynb
# Run all cells (Kernel → Restart & Run All)
```

### Option B: Run individual modules

```python
from src.utils.spark_session import create_spark_session
from src.ingestion.data_loader import load_csv, save_as_parquet
from src.cleaning.data_cleaner import run_cleaning_pipeline
from src.eda.exploratory_analysis import analyze_class_distribution
from src.feature_engineering.feature_builder import run_feature_engineering
from src.sql_analysis.spark_sql_queries import register_temp_view, run_all_sql_analysis

spark = create_spark_session()
df = load_csv(spark, "data/raw/creditcard.csv")
df_clean = run_cleaning_pipeline(df)
df_features = run_feature_engineering(df_clean)
register_temp_view(df_features)
run_all_sql_analysis(spark)
```

---

## 📊 EDA Highlights

### 1. Class Imbalance
- 284,315 legitimate vs 492 fraud transactions
- Fraud rate: **0.172%** — highly imbalanced

### 2. Transaction Amount
- Median fraud amount: **~$22** (much lower than legit ~$87)
- Fraud concentrates in small amounts to avoid detection

### 3. Time Patterns
- Legitimate transactions peak during **business hours**
- Fraud is more uniformly distributed, with a **night-time spike**

### 4. Top Predictive Features
Features most correlated with fraud (by Pearson |r|):
1. V14 (-0.302)
2. V17 (-0.327)
3. V12 (-0.261)
4. V10 (-0.216)
5. V16 (-0.196)

---

## 💡 Business Insights

| # | Insight | Recommended Action |
|---|---|---|
| 1 | 0.172% fraud rate but ~0.27% of total $ | High-value fraud cases deserve priority investigation |
| 2 | Fraud peaks between 10pm–6am | Enable step-up authentication during night hours |
| 3 | Fraud median amount is $22 vs $87 legit | Flag micro-transactions from new merchants |
| 4 | V14, V17, V12 are top fraud signals | Include as primary features in scoring model |
| 5 | Small-amount fraud clustered in $0–$50 band | Lower friction for large transactions, increase for micro |

---

## ⚡ Performance Optimization

### Techniques Applied

| Technique | Where | Benefit |
|---|---|---|
| Explicit schema | `load_csv()` | Skips 1 full data scan |
| Parquet output | After cleaning | 3–10× faster reads vs CSV |
| `cache()` | Before multi-pass EDA | Avoids re-reading disk |
| `coalesce()` | After class filter | Fewer partitions for small result |
| AQE enabled | `spark_config.yaml` | Dynamic partition coalescing |
| Broadcast join threshold | `spark_config.yaml` | Auto-broadcast small tables |
| `approxQuantile()` | IQR outlier detection | ~5× faster than exact sort |
| `explain()` | Debugging | Inspect physical execution plan |

---

## 🎯 Interview Q&A

See [`docs/INTERVIEW_QA.md`](docs/INTERVIEW_QA.md) for 17 detailed interview questions covering:
- PySpark internals (lazy evaluation, DAG, shuffle)
- SQL vs DataFrame API
- Catalyst optimizer & AQE
- Banking domain (imbalanced data, PCA features)
- Debugging slow Spark jobs
- Window functions & rolling aggregations

---

## 📜 License

MIT License — free to use, modify, and share.

---

## 👤 Author

**Your Name**  
[LinkedIn](https://linkedin.com/in/yourprofile) | [GitHub](https://github.com/yourusername)

---

*If this project helped you, please ⭐ star the repository!*
