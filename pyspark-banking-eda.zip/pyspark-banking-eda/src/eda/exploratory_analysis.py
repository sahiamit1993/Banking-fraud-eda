# ============================================================
# src/eda/exploratory_analysis.py
# Full EDA using PySpark — distributions, correlations, fraud
# ============================================================

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from loguru import logger
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
import os


# ── Output Directory ─────────────────────────────────────────
PLOT_DIR = "outputs/plots"
os.makedirs(PLOT_DIR, exist_ok=True)


# ── 1. Class Distribution (Fraud vs Legit) ───────────────────

def analyze_class_distribution(df: DataFrame) -> pd.DataFrame:
    """
    Analyzes and visualizes the fraud vs legitimate class split.

    The Credit Card dataset is highly imbalanced:
    ~99.83% legitimate vs ~0.17% fraud.

    Args:
        df: Cleaned DataFrame.

    Returns:
        Pandas DataFrame with class counts and percentages.
    """
    logger.info("Analyzing class distribution...")

    dist = (
        df.groupBy("Class")
          .count()
          .withColumn("percentage",
                      F.round(F.col("count") / df.count() * 100, 4))
          .orderBy("Class")
    )
    dist.show()

    # Convert to Pandas for plotting
    dist_pd = dist.toPandas()
    dist_pd["Label"] = dist_pd["Class"].map({0: "Legitimate", 1: "Fraud"})

    # --- Plot ---
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    # Bar chart
    axes[0].bar(dist_pd["Label"], dist_pd["count"],
                color=["#2196F3", "#F44336"], edgecolor="white", linewidth=1.2)
    axes[0].set_title("Transaction Count by Class", fontsize=13, fontweight="bold")
    axes[0].set_ylabel("Count")
    for i, v in enumerate(dist_pd["count"]):
        axes[0].text(i, v + 500, f"{v:,}", ha="center", fontsize=10)

    # Pie chart
    axes[1].pie(dist_pd["count"], labels=dist_pd["Label"],
                colors=["#2196F3", "#F44336"],
                autopct="%1.2f%%", startangle=90,
                wedgeprops={"edgecolor": "white", "linewidth": 1.5})
    axes[1].set_title("Class Distribution (%)", fontsize=13, fontweight="bold")

    plt.suptitle("Credit Card Fraud — Class Imbalance Analysis",
                 fontsize=15, fontweight="bold", y=1.02)
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/01_class_distribution.png", dpi=150, bbox_inches="tight")
    plt.show()
    logger.success("Saved: 01_class_distribution.png")

    return dist_pd


# ── 2. Transaction Amount Analysis ───────────────────────────

def analyze_transaction_amounts(df: DataFrame) -> None:
    """
    Compares transaction amount distributions for fraud vs legit.

    Key insight: Fraudulent transactions often cluster at
    smaller amounts to avoid detection.

    Args:
        df: Cleaned DataFrame.
    """
    logger.info("Analyzing transaction amounts by class...")

    # Summary stats by class
    amount_stats = (
        df.groupBy("Class")
          .agg(
              F.count("Amount").alias("count"),
              F.round(F.mean("Amount"), 2).alias("mean"),
              F.round(F.stddev("Amount"), 2).alias("std"),
              F.round(F.min("Amount"), 2).alias("min"),
              F.round(F.expr("percentile_approx(Amount, 0.25)"), 2).alias("q1"),
              F.round(F.expr("percentile_approx(Amount, 0.50)"), 2).alias("median"),
              F.round(F.expr("percentile_approx(Amount, 0.75)"), 2).alias("q3"),
              F.round(F.max("Amount"), 2).alias("max"),
          )
          .orderBy("Class")
    )
    amount_stats.show(truncate=False)

    # Collect amounts to Pandas for plotting (sample to avoid OOM)
    legit_amounts = (df.filter(F.col("Class") == 0)
                       .select("Amount")
                       .sample(0.1, seed=42)
                       .toPandas()["Amount"])

    fraud_amounts = (df.filter(F.col("Class") == 1)
                       .select("Amount")
                       .toPandas()["Amount"])

    # --- Plot ---
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    axes[0].hist(legit_amounts, bins=80, color="#2196F3", alpha=0.7, label="Legitimate")
    axes[0].hist(fraud_amounts, bins=80, color="#F44336", alpha=0.7, label="Fraud")
    axes[0].set_xlabel("Transaction Amount (USD)")
    axes[0].set_ylabel("Frequency")
    axes[0].set_title("Amount Distribution (Full Range)", fontweight="bold")
    axes[0].legend()

    # Zoom in ≤ $500 for clarity
    axes[1].hist(legit_amounts[legit_amounts <= 500], bins=80,
                 color="#2196F3", alpha=0.7, label="Legitimate")
    axes[1].hist(fraud_amounts[fraud_amounts <= 500], bins=80,
                 color="#F44336", alpha=0.7, label="Fraud")
    axes[1].set_xlabel("Transaction Amount (USD)")
    axes[1].set_ylabel("Frequency")
    axes[1].set_title("Amount Distribution (≤ $500)", fontweight="bold")
    axes[1].legend()

    plt.suptitle("Transaction Amount: Fraud vs Legitimate",
                 fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/02_amount_distribution.png", dpi=150, bbox_inches="tight")
    plt.show()
    logger.success("Saved: 02_amount_distribution.png")


# ── 3. Time-based Transaction Patterns ───────────────────────

def analyze_time_patterns(df: DataFrame) -> None:
    """
    Analyzes transaction volume over time (in hours).

    The 'Time' column = seconds elapsed. Converting to hours
    reveals daily patterns: peaks during business hours,
    dips at night.

    Args:
        df: DataFrame with Time column.
    """
    logger.info("Analyzing transaction time patterns...")

    # Convert seconds to hours (0–48 representing 2-day window)
    df_time = df.withColumn("Hour", (F.col("Time") / 3600).cast("int"))

    # Hourly transaction counts by class
    hourly = (
        df_time.groupBy("Hour", "Class")
               .count()
               .orderBy("Hour", "Class")
               .toPandas()
    )

    # --- Plot ---
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)

    # Legit
    legit = hourly[hourly["Class"] == 0]
    axes[0].fill_between(legit["Hour"], legit["count"],
                         alpha=0.6, color="#2196F3")
    axes[0].set_ylabel("Transaction Count")
    axes[0].set_title("Legitimate Transactions — Hourly Volume", fontweight="bold")
    axes[0].grid(alpha=0.3)

    # Fraud
    fraud = hourly[hourly["Class"] == 1]
    axes[1].fill_between(fraud["Hour"], fraud["count"],
                         alpha=0.6, color="#F44336")
    axes[1].set_xlabel("Hour (since start of data collection)")
    axes[1].set_ylabel("Transaction Count")
    axes[1].set_title("Fraudulent Transactions — Hourly Volume", fontweight="bold")
    axes[1].grid(alpha=0.3)

    plt.suptitle("Transaction Volume by Hour: Fraud vs Legitimate",
                 fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/03_time_patterns.png", dpi=150, bbox_inches="tight")
    plt.show()
    logger.success("Saved: 03_time_patterns.png")


# ── 4. Correlation Heatmap (PySpark) ─────────────────────────

def analyze_correlations(df: DataFrame, top_features: int = 10) -> pd.DataFrame:
    """
    Computes pairwise Pearson correlations for top V-features
    with the target Class column.

    PySpark's df.stat.corr() computes single-pair correlations.
    We iterate over all V-features to build the full matrix.

    Args:
        df:           DataFrame with V1–V28, Amount, Class.
        top_features: How many top correlated features to visualise.

    Returns:
        Pandas DataFrame with feature correlation to Class.
    """
    logger.info("Computing feature correlations with Class...")

    feature_cols = [f"V{i}" for i in range(1, 29)] + ["Amount"]

    # Correlation of each feature with Class
    corr_with_class = []
    for col in feature_cols:
        c = df.stat.corr(col, "Class")
        corr_with_class.append({"feature": col, "corr_with_class": round(c, 4)})

    corr_df = pd.DataFrame(corr_with_class).sort_values(
        "corr_with_class", key=abs, ascending=False
    )

    logger.info("Top 10 features correlated with fraud:")
    print(corr_df.head(10).to_string(index=False))

    # --- Plot top_features ---
    top = corr_df.head(top_features)
    colors = ["#F44336" if v > 0 else "#2196F3" for v in top["corr_with_class"]]

    plt.figure(figsize=(10, 6))
    plt.barh(top["feature"], top["corr_with_class"], color=colors)
    plt.axvline(0, color="black", linewidth=0.8, linestyle="--")
    plt.xlabel("Pearson Correlation with Class (Fraud=1)")
    plt.title(f"Top {top_features} Features Correlated with Fraud",
              fontweight="bold", fontsize=13)
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/04_feature_correlations.png", dpi=150, bbox_inches="tight")
    plt.show()
    logger.success("Saved: 04_feature_correlations.png")

    return corr_df


# ── 5. V-Feature Box Plots ────────────────────────────────────

def plot_top_features_boxplot(df: DataFrame, features: list) -> None:
    """
    Plots box plots for key V-features split by Class.

    Allows visual identification of which features have
    the most distinct distributions for fraud vs legit.

    Args:
        df:       DataFrame.
        features: List of feature column names to plot.
    """
    logger.info(f"Plotting boxplots for: {features}")

    # Sample to pandas (V features on 10% is sufficient)
    sample_pd = (
        df.select(features + ["Class"])
          .sample(0.2, seed=42)
          .toPandas()
    )
    sample_pd["Label"] = sample_pd["Class"].map({0: "Legitimate", 1: "Fraud"})

    n = len(features)
    ncols = 4
    nrows = (n + ncols - 1) // ncols

    fig, axes = plt.subplots(nrows, ncols, figsize=(16, nrows * 4))
    axes = axes.flatten()

    for i, feat in enumerate(features):
        sns.boxplot(
            data=sample_pd, x="Label", y=feat,
            palette={"Legitimate": "#2196F3", "Fraud": "#F44336"},
            ax=axes[i], fliersize=2
        )
        axes[i].set_title(feat, fontweight="bold")
        axes[i].set_xlabel("")

    # Hide unused axes
    for j in range(i + 1, len(axes)):
        axes[j].set_visible(False)

    plt.suptitle("Feature Distributions: Fraud vs Legitimate",
                 fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/05_feature_boxplots.png", dpi=150, bbox_inches="tight")
    plt.show()
    logger.success("Saved: 05_feature_boxplots.png")


# ── 6. Fraud Amount Heatmap by Hour ──────────────────────────

def fraud_heatmap_hourly(df: DataFrame) -> None:
    """
    Creates a heatmap of fraud counts binned by hour and amount.

    Reveals temporal and monetary patterns of fraud simultaneously.

    Args:
        df: Cleaned DataFrame.
    """
    logger.info("Building fraud heatmap...")

    fraud_df = df.filter(F.col("Class") == 1)
    fraud_df = fraud_df.withColumn("Hour", (F.col("Time") / 3600).cast("int"))
    fraud_df = fraud_df.withColumn(
        "AmountBin",
        F.when(F.col("Amount") <= 10, "0–10")
         .when(F.col("Amount") <= 50, "10–50")
         .when(F.col("Amount") <= 100, "50–100")
         .when(F.col("Amount") <= 500, "100–500")
         .otherwise("500+")
    )

    heatmap_data = (
        fraud_df.groupBy("Hour", "AmountBin")
                .count()
                .toPandas()
    )

    pivot = heatmap_data.pivot(index="AmountBin", columns="Hour", values="count").fillna(0)
    amount_order = ["0–10", "10–50", "50–100", "100–500", "500+"]
    pivot = pivot.reindex([x for x in amount_order if x in pivot.index])

    plt.figure(figsize=(16, 5))
    sns.heatmap(pivot, cmap="Reds", linewidths=0.3,
                linecolor="white", cbar_kws={"label": "Fraud Count"})
    plt.title("Fraud Heatmap: Hour vs Amount Band", fontsize=13, fontweight="bold")
    plt.xlabel("Hour")
    plt.ylabel("Amount Range (USD)")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/06_fraud_heatmap.png", dpi=150, bbox_inches="tight")
    plt.show()
    logger.success("Saved: 06_fraud_heatmap.png")
