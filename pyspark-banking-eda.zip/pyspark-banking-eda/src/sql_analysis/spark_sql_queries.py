# ============================================================
# src/sql_analysis/spark_sql_queries.py
# Spark SQL analysis — business queries on fraud data
# ============================================================

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from loguru import logger


def register_temp_view(df: DataFrame, view_name: str = "transactions") -> None:
    """
    Registers DataFrame as a Spark SQL temporary view.

    A temp view exists only for the current SparkSession
    and is dropped automatically when it stops.

    Args:
        df:        DataFrame to register.
        view_name: SQL table name.
    """
    df.createOrReplaceTempView(view_name)
    logger.info(f"Temp view registered: '{view_name}'")


# ── Query 1: Fraud Rate by Hour ───────────────────────────────

def query_fraud_rate_by_hour(spark: SparkSession) -> DataFrame:
    """
    Returns hourly fraud rate as a percentage.

    Business Use:
        Identify peak fraud hours to trigger enhanced monitoring
        or additional authentication steps.
    """
    logger.info("Running Query 1: Fraud rate by hour...")

    return spark.sql("""
        SELECT
            CAST(Time / 3600 AS INT) AS Hour,
            COUNT(*)                 AS total_transactions,
            SUM(Class)               AS fraud_count,
            ROUND(SUM(Class) * 100.0 / COUNT(*), 4) AS fraud_rate_pct
        FROM transactions
        GROUP BY Hour
        ORDER BY fraud_rate_pct DESC
        LIMIT 20
    """)


# ── Query 2: Fraud by Amount Band ─────────────────────────────

def query_fraud_by_amount_band(spark: SparkSession) -> DataFrame:
    """
    Breaks down fraud count and rate by transaction amount bucket.

    Business Use:
        Determine which amount ranges are most susceptible
        to fraud → inform transaction limit policies.
    """
    logger.info("Running Query 2: Fraud by amount band...")

    return spark.sql("""
        SELECT
            CASE
                WHEN Amount <= 10   THEN 'A: $0–$10'
                WHEN Amount <= 50   THEN 'B: $10–$50'
                WHEN Amount <= 100  THEN 'C: $50–$100'
                WHEN Amount <= 500  THEN 'D: $100–$500'
                WHEN Amount <= 2000 THEN 'E: $500–$2000'
                ELSE                     'F: >$2000'
            END                    AS AmountBand,
            COUNT(*)               AS total_transactions,
            SUM(Class)             AS fraud_count,
            ROUND(AVG(Amount), 2)  AS avg_amount,
            ROUND(SUM(Class) * 100.0 / COUNT(*), 4) AS fraud_rate_pct
        FROM transactions
        GROUP BY AmountBand
        ORDER BY AmountBand
    """)


# ── Query 3: Total Fraud Value ────────────────────────────────

def query_fraud_financial_impact(spark: SparkSession) -> DataFrame:
    """
    Computes total financial exposure from fraud transactions.

    Business Use:
        Quantify dollar value at risk; prioritise response by
        the highest-value fraudulent transactions.
    """
    logger.info("Running Query 3: Fraud financial impact...")

    return spark.sql("""
        SELECT
            'Total Transactions'   AS metric,
            COUNT(*)               AS value,
            ROUND(SUM(Amount), 2)  AS total_amount_usd
        FROM transactions

        UNION ALL

        SELECT
            'Fraud Transactions',
            COUNT(*),
            ROUND(SUM(Amount), 2)
        FROM transactions
        WHERE Class = 1

        UNION ALL

        SELECT
            'Legitimate Transactions',
            COUNT(*),
            ROUND(SUM(Amount), 2)
        FROM transactions
        WHERE Class = 0
    """)


# ── Query 4: High-Value Fraud Transactions ────────────────────

def query_top_fraud_transactions(spark: SparkSession, top_n: int = 20) -> DataFrame:
    """
    Retrieves the top N highest-value fraudulent transactions.

    Business Use:
        Manual review candidates for the fraud investigation team.
    """
    logger.info(f"Running Query 4: Top {top_n} fraud transactions...")

    return spark.sql(f"""
        SELECT
            Time,
            Amount,
            ROUND(Time / 3600, 1) AS Hour,
            Class
        FROM transactions
        WHERE Class = 1
        ORDER BY Amount DESC
        LIMIT {top_n}
    """)


# ── Query 5: Rolling Fraud Rate ───────────────────────────────

def query_rolling_fraud_rate(spark: SparkSession, bin_hours: int = 2) -> DataFrame:
    """
    Computes fraud rate in rolling time bins.

    Business Use:
        Detect surges — sudden spikes in fraud rate over
        short windows trigger automated alerts.

    Args:
        bin_hours: Width of each time bin in hours.
    """
    logger.info(f"Running Query 5: Rolling fraud rate (bins={bin_hours}h)...")

    return spark.sql(f"""
        SELECT
            CAST(CAST(Time / 3600 AS INT) / {bin_hours} AS INT) * {bin_hours} AS HourBin,
            COUNT(*)                AS total,
            SUM(Class)              AS fraud_count,
            ROUND(SUM(Class) * 100.0 / COUNT(*), 4) AS fraud_rate_pct,
            ROUND(AVG(Amount), 2)   AS avg_amount
        FROM transactions
        GROUP BY HourBin
        ORDER BY HourBin
    """)


# ── Query 6: Fraud Percentile Distribution ────────────────────

def query_fraud_amount_percentiles(spark: SparkSession) -> DataFrame:
    """
    Computes percentile distribution of fraudulent amounts.

    Business Use:
        Establish thresholds for rules-based fraud scoring
        (e.g., flag transactions above 95th percentile amount).
    """
    logger.info("Running Query 6: Fraud amount percentiles...")

    return spark.sql("""
        SELECT
            ROUND(percentile_approx(Amount, 0.25), 2)  AS p25,
            ROUND(percentile_approx(Amount, 0.50), 2)  AS p50_median,
            ROUND(percentile_approx(Amount, 0.75), 2)  AS p75,
            ROUND(percentile_approx(Amount, 0.90), 2)  AS p90,
            ROUND(percentile_approx(Amount, 0.95), 2)  AS p95,
            ROUND(percentile_approx(Amount, 0.99), 2)  AS p99,
            ROUND(MAX(Amount), 2)                      AS max
        FROM transactions
        WHERE Class = 1
    """)


# ── Run All Queries ───────────────────────────────────────────

def run_all_sql_analysis(spark: SparkSession) -> dict:
    """
    Executes all SQL queries and returns results as a dict.

    Args:
        spark: Active SparkSession with 'transactions' view registered.

    Returns:
        Dict of {query_name: DataFrame}
    """
    logger.info("=== Running All Spark SQL Queries ===")

    results = {
        "fraud_by_hour":       query_fraud_rate_by_hour(spark),
        "fraud_by_amount":     query_fraud_by_amount_band(spark),
        "financial_impact":    query_fraud_financial_impact(spark),
        "top_fraud_txns":      query_top_fraud_transactions(spark),
        "rolling_fraud_rate":  query_rolling_fraud_rate(spark),
        "fraud_percentiles":   query_fraud_amount_percentiles(spark),
    }

    for name, df in results.items():
        logger.info(f"\n─── {name} ───")
        df.show(truncate=False)

    logger.success("=== All SQL Queries Complete ===")
    return results
