# ============================================================
# src/ingestion/data_loader.py
# Data ingestion: CSV → Parquet with schema enforcement
# ============================================================

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import (
    StructType, StructField,
    DoubleType, IntegerType, StringType
)
from pyspark.sql import functions as F
from loguru import logger
import os


# ── Schema Definition ────────────────────────────────────────

def get_creditcard_schema() -> StructType:
    """
    Defines the explicit schema for the Credit Card Fraud dataset.

    Dataset columns:
    - Time:   Seconds elapsed since first transaction
    - V1–V28: PCA-transformed anonymised features
    - Amount: Transaction amount (USD)
    - Class:  0 = legitimate, 1 = fraudulent

    Returns:
        StructType schema for the CSV.
    """
    fields = [StructField("Time", DoubleType(), True)]

    # V1 through V28 — PCA components
    for i in range(1, 29):
        fields.append(StructField(f"V{i}", DoubleType(), True))

    fields += [
        StructField("Amount", DoubleType(), True),
        StructField("Class",  IntegerType(), True),
    ]
    return StructType(fields)


# ── CSV Loader ───────────────────────────────────────────────

def load_csv(spark: SparkSession, path: str, infer_schema: bool = False) -> DataFrame:
    """
    Loads the raw Credit Card CSV file into a PySpark DataFrame.

    Uses explicit schema by default (faster than inferSchema=True
    which requires two full scans of the data).

    Args:
        spark:        Active SparkSession.
        path:         Path to the CSV file.
        infer_schema: Set True to infer schema (slower but flexible).

    Returns:
        PySpark DataFrame with all transactions.

    Example:
        >>> df = load_csv(spark, "data/raw/creditcard.csv")
        >>> df.count()
        284807
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Dataset not found at '{path}'.\n"
            "Download it from: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud\n"
            "Place 'creditcard.csv' inside data/raw/"
        )

    schema = None if infer_schema else get_creditcard_schema()

    logger.info(f"Loading CSV from: {path}")
    df = (
        spark.read
        .option("header", "true")
        .option("inferSchema", str(infer_schema).lower())
        .schema(schema)        # explicit schema skips one full pass
        .csv(path)
    )

    logger.success(f"Loaded {df.count():,} rows | {len(df.columns)} columns")
    return df


# ── Parquet Writer ───────────────────────────────────────────

def save_as_parquet(df: DataFrame, output_path: str,
                    partition_by: str = None, mode: str = "overwrite") -> None:
    """
    Saves a DataFrame as Parquet (columnar, compressed, fast).

    Parquet advantages over CSV:
    - 3-10× faster reads (column pruning + predicate pushdown)
    - ~75% smaller file size (Snappy compression by default)
    - Schema embedded in file (no re-inference needed)

    Args:
        df:           DataFrame to save.
        output_path:  Output directory path.
        partition_by: Optional column to partition output by.
        mode:         'overwrite' | 'append' | 'ignore' | 'error'
    """
    writer = df.write.mode(mode).parquet

    if partition_by:
        logger.info(f"Saving Parquet partitioned by '{partition_by}' → {output_path}")
        df.write.mode(mode).partitionBy(partition_by).parquet(output_path)
    else:
        logger.info(f"Saving Parquet → {output_path}")
        df.write.mode(mode).parquet(output_path)

    logger.success(f"Parquet saved to: {output_path}")


# ── Parquet Loader ───────────────────────────────────────────

def load_parquet(spark: SparkSession, path: str) -> DataFrame:
    """
    Loads a Parquet file or directory into a DataFrame.

    Args:
        spark: Active SparkSession.
        path:  Path to Parquet file/directory.

    Returns:
        PySpark DataFrame.
    """
    logger.info(f"Loading Parquet from: {path}")
    df = spark.read.parquet(path)
    logger.success(f"Loaded Parquet: {df.count():,} rows | {len(df.columns)} columns")
    return df


# ── Sample Creator ───────────────────────────────────────────

def create_sample(df: DataFrame, fraction: float = 0.1,
                  seed: int = 42, output_path: str = None) -> DataFrame:
    """
    Creates a stratified sample preserving Class distribution.

    Useful for quick iteration during development without
    needing to run full 284K rows every time.

    Args:
        df:          Full DataFrame.
        fraction:    Sampling fraction (default 10%).
        seed:        Random seed for reproducibility.
        output_path: If provided, saves sample as Parquet.

    Returns:
        Sampled DataFrame.
    """
    logger.info(f"Creating {fraction*100:.0f}% stratified sample...")

    # Stratified sample to preserve Class 0/1 ratio
    fractions = {0: fraction, 1: fraction}
    sample_df = df.sampleBy("Class", fractions=fractions, seed=seed)

    sample_count = sample_df.count()
    logger.success(f"Sample size: {sample_count:,} rows")

    if output_path:
        sample_df.write.mode("overwrite").parquet(output_path)
        logger.info(f"Sample saved to: {output_path}")

    return sample_df
