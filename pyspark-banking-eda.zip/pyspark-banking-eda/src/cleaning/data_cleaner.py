# ============================================================
# src/cleaning/data_cleaner.py
# Data cleaning pipeline: nulls, duplicates, outliers, types
# ============================================================

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType
from loguru import logger


# ── Null Handling ────────────────────────────────────────────

def drop_null_rows(df: DataFrame, subset: list = None) -> DataFrame:
    """
    Drops rows with any null values.

    Args:
        df:     Input DataFrame.
        subset: Columns to check. None = check all.

    Returns:
        DataFrame with null rows removed.
    """
    before = df.count()
    df_clean = df.dropna(subset=subset)
    after = df_clean.count()
    dropped = before - after
    logger.info(f"Dropped {dropped:,} null rows ({dropped/before*100:.2f}%)")
    return df_clean


def fill_nulls(df: DataFrame, fill_map: dict) -> DataFrame:
    """
    Fills null values using a column→value mapping.

    Args:
        df:       Input DataFrame.
        fill_map: Dict of {column_name: fill_value}.
                  Example: {"Amount": 0.0, "Class": 0}

    Returns:
        DataFrame with nulls filled.
    """
    logger.info(f"Filling nulls: {fill_map}")
    return df.fillna(fill_map)


# ── Duplicate Removal ────────────────────────────────────────

def remove_duplicates(df: DataFrame, subset: list = None) -> DataFrame:
    """
    Removes duplicate rows from the DataFrame.

    Args:
        df:     Input DataFrame.
        subset: Columns to define uniqueness. None = all columns.

    Returns:
        Deduplicated DataFrame.
    """
    before = df.count()
    df_dedup = df.dropDuplicates(subset=subset)
    after = df_dedup.count()
    logger.info(f"Removed {before - after:,} duplicate rows")
    return df_dedup


# ── Outlier Detection (IQR Method) ───────────────────────────

def cap_outliers_iqr(df: DataFrame, col: str,
                     multiplier: float = 1.5) -> DataFrame:
    """
    Caps outliers in a numeric column using the IQR method.

    Strategy: Winsorization (cap at boundaries, don't remove rows).
    - Lower fence = Q1 - multiplier × IQR
    - Upper fence = Q3 + multiplier × IQR
    - Values outside fences are clipped to the fence values.

    Why Winsorization over removal?
    - Fraud datasets are imbalanced; removing rows can discard
      rare but important fraud patterns.

    Args:
        df:          Input DataFrame.
        col:         Numeric column to cap outliers in.
        multiplier:  IQR multiplier (default 1.5 = mild outlier).

    Returns:
        DataFrame with outliers capped.
    """
    # Compute quartiles
    quantiles = df.approxQuantile(col, [0.25, 0.75], 0.01)
    q1, q3 = quantiles[0], quantiles[1]
    iqr = q3 - q1

    lower = q1 - multiplier * iqr
    upper = q3 + multiplier * iqr

    logger.info(f"'{col}' outlier bounds: [{lower:.4f}, {upper:.4f}]")

    df_capped = df.withColumn(
        col,
        F.when(F.col(col) < lower, lower)
         .when(F.col(col) > upper, upper)
         .otherwise(F.col(col))
    )
    return df_capped


# ── Type Casting ─────────────────────────────────────────────

def cast_columns(df: DataFrame, cast_map: dict) -> DataFrame:
    """
    Casts columns to specified types.

    Args:
        df:       Input DataFrame.
        cast_map: Dict of {column_name: spark_type}.
                  Example: {"Amount": DoubleType(), "Class": IntegerType()}

    Returns:
        DataFrame with recast columns.
    """
    for col_name, target_type in cast_map.items():
        logger.info(f"Casting '{col_name}' → {target_type}")
        df = df.withColumn(col_name, F.col(col_name).cast(target_type))
    return df


# ── Negative Value Filter ────────────────────────────────────

def remove_negative_amounts(df: DataFrame) -> DataFrame:
    """
    Removes transactions with negative Amount values.

    In real banking data, negative amounts indicate refunds or
    reversals which are handled separately.

    Args:
        df: Input DataFrame.

    Returns:
        DataFrame with only non-negative amounts.
    """
    before = df.count()
    df_filtered = df.filter(F.col("Amount") >= 0)
    after = df_filtered.count()
    logger.info(f"Removed {before - after:,} rows with negative Amount")
    return df_filtered


# ── Master Cleaning Pipeline ─────────────────────────────────

def run_cleaning_pipeline(df: DataFrame) -> DataFrame:
    """
    Executes the full data cleaning pipeline in sequence:
    1. Remove negatives
    2. Drop nulls
    3. Remove duplicates
    4. Cap Amount outliers (fraud patterns preserved)

    Args:
        df: Raw DataFrame.

    Returns:
        Cleaned DataFrame.
    """
    logger.info("=== Starting Data Cleaning Pipeline ===")

    df = remove_negative_amounts(df)
    df = drop_null_rows(df)
    df = remove_duplicates(df)
    df = cap_outliers_iqr(df, col="Amount", multiplier=3.0)  # 3× IQR = extreme outlier

    logger.success("=== Cleaning Pipeline Complete ===")
    return df
