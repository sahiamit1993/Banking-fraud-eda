# ============================================================
# src/utils/helpers.py
# Reusable helper functions used across all modules
# ============================================================

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from loguru import logger
import time


# ── DataFrame Profiling ──────────────────────────────────────

def profile_dataframe(df: DataFrame, sample_rows: int = 5) -> None:
    """
    Prints a comprehensive profile of a PySpark DataFrame:
    shape, schema, null counts, and sample rows.

    Args:
        df: PySpark DataFrame to profile.
        sample_rows: Number of rows to display.
    """
    row_count = df.count()
    col_count = len(df.columns)

    logger.info(f"Shape: {row_count:,} rows × {col_count} columns")
    logger.info("Schema:")
    df.printSchema()

    # Null counts per column
    null_counts = df.select([
        F.count(F.when(F.col(c).isNull(), c)).alias(c)
        for c in df.columns
    ])
    logger.info("Null counts per column:")
    null_counts.show(truncate=False)

    # Sample rows
    logger.info(f"Sample {sample_rows} rows:")
    df.show(sample_rows, truncate=True)


# ── Null Analysis ────────────────────────────────────────────

def null_percentage_report(df: DataFrame) -> DataFrame:
    """
    Returns a DataFrame with null count and null percentage
    for each column, sorted by percentage descending.

    Args:
        df: Input DataFrame.

    Returns:
        DataFrame with columns: column_name, null_count, null_pct
    """
    total = df.count()

    null_report = df.select([
        F.count(F.when(F.col(c).isNull(), c)).alias(c)
        for c in df.columns
    ]).toPandas().T.reset_index()

    null_report.columns = ["column_name", "null_count"]
    null_report["null_pct"] = (null_report["null_count"] / total * 100).round(2)
    null_report = null_report.sort_values("null_pct", ascending=False)
    return null_report


# ── Duplicate Detection ──────────────────────────────────────

def count_duplicates(df: DataFrame, subset: list = None) -> int:
    """
    Counts duplicate rows in a DataFrame.

    Args:
        df: Input DataFrame.
        subset: Column names to check for duplicates. Defaults to all.

    Returns:
        Number of duplicate rows.
    """
    total = df.count()
    distinct = df.dropDuplicates(subset=subset).count() if subset else df.distinct().count()
    duplicates = total - distinct
    logger.info(f"Duplicate rows: {duplicates:,} ({duplicates/total*100:.2f}%)")
    return duplicates


# ── Timer Decorator ──────────────────────────────────────────

def timeit(func):
    """
    Decorator that logs execution time of any function.

    Usage:
        @timeit
        def my_function():
            ...
    """
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        logger.info(f"{func.__name__} completed in {elapsed:.2f}s")
        return result
    return wrapper


# ── Column Statistics ────────────────────────────────────────

def numeric_summary(df: DataFrame, cols: list) -> DataFrame:
    """
    Returns descriptive statistics for selected numeric columns.

    Args:
        df: Input DataFrame.
        cols: List of numeric column names.

    Returns:
        PySpark DataFrame with describe() stats.
    """
    return df.select(cols).describe()


# ── Repartitioning Helper ────────────────────────────────────

def repartition_by_column(df: DataFrame, col: str, num_partitions: int = 8) -> DataFrame:
    """
    Repartitions a DataFrame by a categorical column for
    optimized downstream operations.

    Args:
        df: Input DataFrame.
        col: Column to partition by.
        num_partitions: Target number of partitions.

    Returns:
        Repartitioned DataFrame.
    """
    logger.info(f"Repartitioning by '{col}' into {num_partitions} partitions...")
    return df.repartition(num_partitions, F.col(col))
