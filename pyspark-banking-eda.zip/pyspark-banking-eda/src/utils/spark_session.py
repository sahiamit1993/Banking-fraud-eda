# ============================================================
# src/utils/spark_session.py
# Centralized SparkSession factory with tuned configuration
# ============================================================

import yaml
from pyspark.sql import SparkSession
from loguru import logger


def create_spark_session(config_path: str = "config/spark_config.yaml") -> SparkSession:
    """
    Creates and returns a configured SparkSession.

    Reads spark settings from YAML config and applies them
    so every notebook/script uses identical settings.

    Args:
        config_path: Path to the YAML config file.

    Returns:
        SparkSession: Fully configured Spark session.

    Example:
        >>> spark = create_spark_session()
        >>> spark.version
        '3.5.1'
    """
    # Load YAML config
    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)

    spark_cfg = cfg["spark"]

    logger.info(f"Initializing SparkSession: {spark_cfg['app_name']}")

    spark = (
        SparkSession.builder
        .appName(spark_cfg["app_name"])
        .master(spark_cfg["master"])

        # --- Memory ---
        .config("spark.driver.memory",              spark_cfg["driver_memory"])
        .config("spark.executor.memory",            spark_cfg["executor_memory"])
        .config("spark.driver.maxResultSize",       spark_cfg["driver_max_result_size"])

        # --- Shuffle & Adaptive Query Execution ---
        .config("spark.sql.shuffle.partitions",     spark_cfg["sql_shuffle_partitions"])
        .config("spark.sql.adaptive.enabled",       spark_cfg["adaptive_enabled"])
        .config("spark.sql.adaptive.coalescePartitions.enabled",
                                                    spark_cfg["adaptive_coalesce_enabled"])
        .config("spark.sql.autoBroadcastJoinThreshold",
                spark_cfg["broadcast_threshold"])

        # --- Parquet ---
        .config("spark.sql.parquet.mergeSchema",    spark_cfg["parquet_mergeSchema"])
        .config("spark.sql.parquet.filterPushdown", spark_cfg["parquet_filterPushdown"])

        # --- UI (useful during dev; disable in prod) ---
        .config("spark.ui.showConsoleProgress", "false")

        .getOrCreate()
    )

    # Set log level to suppress verbose INFO messages
    spark.sparkContext.setLogLevel(spark_cfg["log_level"])

    logger.success(f"SparkSession ready | Spark {spark.version} | Master: {spark_cfg['master']}")
    return spark


def stop_spark(spark: SparkSession) -> None:
    """Gracefully stops the SparkSession."""
    spark.stop()
    logger.info("SparkSession stopped.")
