# ============================================================
# src/feature_engineering/feature_builder.py
# Feature engineering: time bins, scaling, aggregations
# ============================================================

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.ml.feature import (
    VectorAssembler, StandardScaler,
    MinMaxScaler, StringIndexer
)
from pyspark.ml import Pipeline
from loguru import logger


# ── 1. Time-based Features ───────────────────────────────────

def add_time_features(df: DataFrame) -> DataFrame:
    """
    Derives time-based features from the raw 'Time' column.

    Features created:
    - Hour:       0–47 (hour within the 2-day window)
    - DayPeriod:  Morning / Afternoon / Evening / Night
    - IsNight:    Binary flag for 10pm–6am transactions
                  (fraud rate is higher at night)

    Args:
        df: DataFrame with 'Time' column (seconds).

    Returns:
        DataFrame with new time columns added.
    """
    logger.info("Adding time-based features...")

    df = df.withColumn("Hour", (F.col("Time") / 3600).cast("int"))

    # Map hour to day period (cyclic 24h)
    hour_mod = F.col("Hour") % 24
    df = df.withColumn(
        "DayPeriod",
        F.when((hour_mod >= 6)  & (hour_mod < 12), "Morning")
         .when((hour_mod >= 12) & (hour_mod < 18), "Afternoon")
         .when((hour_mod >= 18) & (hour_mod < 22), "Evening")
         .otherwise("Night")
    )

    # Night flag: 10pm–6am → higher fraud rate
    df = df.withColumn(
        "IsNight",
        F.when((hour_mod >= 22) | (hour_mod < 6), 1).otherwise(0)
    )

    logger.success("Time features added: Hour, DayPeriod, IsNight")
    return df


# ── 2. Amount-based Features ─────────────────────────────────

def add_amount_features(df: DataFrame) -> DataFrame:
    """
    Creates amount-derived features.

    Features created:
    - LogAmount:  Log1p-transformed amount (reduces skewness)
    - AmountBin:  Categorical bucket (Small / Medium / Large / Very Large)
    - IsLargeAmt: Binary flag for amounts > 1000 (unusual, warrants attention)

    Args:
        df: DataFrame with 'Amount' column.

    Returns:
        DataFrame with amount features.
    """
    logger.info("Adding amount-based features...")

    # Log transform reduces the extreme right skew of Amount
    df = df.withColumn("LogAmount", F.log1p(F.col("Amount")))

    # Binning amounts
    df = df.withColumn(
        "AmountBin",
        F.when(F.col("Amount") <= 10,   "Small")
         .when(F.col("Amount") <= 100,  "Medium")
         .when(F.col("Amount") <= 1000, "Large")
         .otherwise("VeryLarge")
    )

    # Flag for unusually large transactions
    df = df.withColumn(
        "IsLargeAmt",
        F.when(F.col("Amount") > 1000, 1).otherwise(0)
    )

    logger.success("Amount features added: LogAmount, AmountBin, IsLargeAmt")
    return df


# ── 3. Rolling Window Aggregation ────────────────────────────

def add_rolling_features(df: DataFrame, window_size: int = 10) -> DataFrame:
    """
    Adds rolling statistics over the last N transactions
    ordered by Time. Useful for velocity-based fraud detection.

    Features created:
    - RollingAvgAmount: Mean amount over last `window_size` txns
    - RollingMaxAmount: Max amount over last `window_size` txns
    - TxnRank:          Sequential rank of transaction by time

    Note: Row-based window (no partition) — appropriate since
    this dataset doesn't have a customer/account ID column.

    Args:
        df:          DataFrame with 'Time' and 'Amount'.
        window_size: Look-back window size (number of rows).

    Returns:
        DataFrame with rolling features.
    """
    logger.info(f"Adding rolling features (window={window_size})...")

    # Order by Time ascending
    w = Window.orderBy("Time").rowsBetween(-window_size, -1)

    df = (
        df.withColumn("RollingAvgAmount", F.round(F.avg("Amount").over(w), 2))
          .withColumn("RollingMaxAmount", F.round(F.max("Amount").over(w), 2))
          .withColumn("TxnRank",          F.row_number().over(Window.orderBy("Time")))
    )

    logger.success("Rolling features added: RollingAvgAmount, RollingMaxAmount, TxnRank")
    return df


# ── 4. Feature Scaling (PySpark ML Pipeline) ─────────────────

def build_scaling_pipeline(feature_cols: list) -> Pipeline:
    """
    Builds a PySpark ML Pipeline that:
    1. Assembles feature columns into a single vector
    2. Applies StandardScaler (zero mean, unit std)

    StandardScaler is preferred for PCA-derived V-features
    as they may still have different variances.

    Args:
        feature_cols: List of numeric column names to scale.

    Returns:
        Unfitted PySpark ML Pipeline.

    Example:
        >>> pipe = build_scaling_pipeline(["LogAmount", "V1", "V2"])
        >>> model = pipe.fit(df)
        >>> df_scaled = model.transform(df)
    """
    assembler = VectorAssembler(
        inputCols=feature_cols,
        outputCol="features_raw",
        handleInvalid="skip"      # skip rows with null in any feature col
    )

    scaler = StandardScaler(
        inputCol="features_raw",
        outputCol="features_scaled",
        withMean=True,            # subtract mean
        withStd=True              # divide by std
    )

    pipeline = Pipeline(stages=[assembler, scaler])
    logger.info("Scaling pipeline built (VectorAssembler → StandardScaler)")
    return pipeline


# ── 5. Master Feature Engineering Pipeline ───────────────────

def run_feature_engineering(df: DataFrame) -> DataFrame:
    """
    Runs all feature engineering steps in sequence:
    1. Time features
    2. Amount features
    3. Rolling window features

    Args:
        df: Cleaned DataFrame.

    Returns:
        Feature-enriched DataFrame.
    """
    logger.info("=== Starting Feature Engineering Pipeline ===")
    df = add_time_features(df)
    df = add_amount_features(df)
    df = add_rolling_features(df, window_size=10)
    logger.success("=== Feature Engineering Complete ===")
    return df
